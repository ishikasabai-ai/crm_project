export default function Footer() {
  return (
    <footer className="px-10 py-10 bg-black text-white">
      <p>© 2021 Whitepace LLC</p>
    </footer>
  );}