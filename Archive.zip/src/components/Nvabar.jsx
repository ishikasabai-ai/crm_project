export default function Navbar() {
  return (
    <nav className="flex text-white justify-between items-center px-10 py-4 shadow bg-[#043873]">
      <h1 className="text-2xl font-bold">Crivient</h1>
      <ul className="flex gap-6">
        <li>Products</li>
        <li>About us</li>
        <li>Contact us</li>
        <li>Resources</li>
        <li>Pricing</li>
      </ul>
      <button className="bg-blue-600 text-white px-4 py-2 rounded">Try Free</button>
    </nav>
  );
}