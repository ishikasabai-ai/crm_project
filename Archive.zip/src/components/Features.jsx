export default function Features() {
  return (
    <section className="px-10 py-20">
      <h3 className="text-3xl font-bold mb-10">Features</h3>
      <div className="grid grid-cols-4 gap-10">
        <div className="p-6 font-bold text-2xl  h-70 shadow-2xl rounded-2xl">Lead & Contact Management</div>
        <div className="p-6 shadow-2xl font-bold text-2xl rounded-2xl">Sales Pipeline & Deal Tracking</div>
        <div className="p-6 shadow-2xl font-semibold text-2xl  rounded-2xl">Automation & Workflows</div>
        <div className="p-6 shadow-2xl font-bold text-2xl rounded-2xl">Automation & Workflows</div>

      </div>
    </section>
  );
}