export default function Pricing() {
  return (
    <section className="px-10 py-20 bg-gray-50">
      <h3 className="text-3xl font-bold mb-10">Choose Your Plan</h3>
      <div className="grid grid-cols-3 gap-8">
        <div className="border p-6 rounded">
          <h4 className="font-bold">Free</h4>
          <p>$0</p>
        </div>
        <div className="border p-6 rounded">
          <h4 className="font-bold">Personal</h4>
          <p>$11.99</p>
        </div>
        <div className="border p-6 rounded">
          <h4 className="font-bold">Organization</h4>
          <p>$49.99</p>
        </div>
      </div>
    </section>
  );
}