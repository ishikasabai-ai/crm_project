export default function Testimonials() {
  return (
    <section className="px-10 py-20">
      <h3 className="text-3xl font-bold mb-10">What Our Clients Say</h3>
      <div className="grid grid-cols-3 gap-8">
        <div className="p-6 shadow rounded">Great CRM tool</div>
        <div className="p-6 shadow rounded">Boosted productivity</div>
        <div className="p-6 shadow rounded">Excellent collaboration</div>
      </div>
    </section>
  );
}