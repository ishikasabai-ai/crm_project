import crm from "../assets/crm.jpeg";

export default function Hero() {
  return (
    <section className="grid grid-cols-2 px-10 py-20 items-center shadow bg-[#043873]">
      
      {/* Left Content */}
      <div className="text-white">
        <h2 className="text-5xl font-bold mb-6">
          Smart CRM Software for Growing Businesses
        </h2>

        <p className="text-gray-200 mb-6">
          Organize customer data, streamline sales operations, improve team productivity, and build
          long-lasting customer relationships with a powerful all-in-one CRM platform.
        </p>

        <button className="bg-[#4F9CF9] text-[#043873] px-6 py-3 rounded font-semibold hover:bg-gray-100">
          Try Crivient free
        </button>
      </div>

      {/* Right Image */}
      <img
        src={crm}
        alt="CRM Dashboard"
        className="h-90 rounded-lg shadow-lg ml-30"
      />

    </section>
  );
}